from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib import messages
from .models import *
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic
from django.contrib.auth.decorators import login_required


class SignUp(generic.CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy("login")
    template_name = "registration/signup.html"

#index view
def index(request):
    return render(request,'index.html')

#dashboard view
@login_required(login_url='/accounts/login/')
def dashboard(request):
    if request.method=='POST':
        district=request.POST['district']
        city=request.POST['city']
        vaccine=request.POST['vaccine']
        age=request.POST['age']
        date = request.POST['date']
        print(district,city,vaccine,age,date)
        return HttpResponse('output:'+district+' '+city+' '+date)
    else:
        return render(request,'dashboard.html')

#bookdetails view
@login_required(login_url='/accounts/login/')
def bookdetails(request):
    return render(request,'bookdetails.html')

@login_required(login_url='/accounts/login/')
def viewbookings(request):
    return render(request,"viewbookings.html")