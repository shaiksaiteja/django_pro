from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('user', '0003_registration'),
    ]

    operations = [
        migrations.DeleteModel(
            name='Registration',
        ),
        migrations.CreateModel(
            name='SignupModel',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('username', models.CharField(max_length=100)),
                ('Email', models.EmailField(max_length=254)),
                ('Password', models.CharField(max_length=50)),
            ],
            options={
                'db_table': 'Registration',
            },
        ),
    ]

